# Recipe Application

This application allows users to create, manage, and display recipes. Users can enter the recipe details, including the recipe name, ingredients, and steps. They can also view all the created recipes or select a specific recipe to display its details.

## Instructions

To compile and run the software, follow these steps:

1. Ensure you have the .NET SDK installed on your machine. You can download it from the official [.NET website](https://dotnet.microsoft.com/download).

2. Clone the GitHub repository using the following command:
git clone https://github.com/your-username/recipe-application.git

3. Navigate to the project directory:
cd recipe-application


4. Build the project using the following command:
dotnet build


5. Run the application:
dotnet run


6. Follow the on-screen prompts to interact with the recipe application.

## GitHub Repository

The source code for this recipe application can be found on [GitHub](https://github.com/your-username/recipe-application).

## Feedback-Based Changes

Based on the feedback from my lecturer, the following changes were made to the application:

- The original code was structured into separate classes, with each class placed in its own external file to improve code organization and maintainability.
- The RecipeManager class was introduced to handle recipe management operations such as adding recipes, displaying all recipes, and displaying a specific recipe.
- The Ingredient class was separated into its own file for better encapsulation and readability.
- A README file was created to provide clear instructions for compiling and running the software, along with a link to the GitHub repository for easy access.

These changes address the lecturer's suggestions to improve code structure, organization, and maintainability, making the application more robust and easier to understand for future development and collaboration.
