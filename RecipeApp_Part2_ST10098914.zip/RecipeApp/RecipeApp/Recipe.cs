﻿using RecipeApp.RecipeApplication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{
    class Recipe
    {
        public string Name { get; set; }
        private List<Ingredient> ingredients;
        private List<string> steps;

        public Recipe()
        {
            ingredients = new List<Ingredient>();
            steps = new List<string>();
        }

        public void EnterDetails()
        {
            Console.WriteLine("Enter recipe name: ");
            Name = Console.ReadLine();

            EnterIngredients();
            EnterSteps();
        }

        private void EnterIngredients()
        {
            Console.WriteLine("Enter the number of ingredients: ");
            int ingredientCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < ingredientCount; i++)
            {
                Console.WriteLine("Enter ingredient name: ");
                string name = Console.ReadLine();

                Console.WriteLine("Enter ingredient quantity: ");
                string quantity = Console.ReadLine();

                Console.WriteLine("Enter ingredient unit of measurement: ");
                string unit = Console.ReadLine();

                Console.WriteLine("Enter ingredient calories: ");
                int calories = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter ingredient food group: ");
                string foodGroup = Console.ReadLine();

                Ingredient ingredient = new Ingredient
                {
                    Name = name,
                    Quantity = quantity,
                    Unit = unit,
                    Calories = calories,
                    FoodGroup = foodGroup
                };

                ingredients.Add(ingredient);
            }
        }

        private void EnterSteps()
        {
            Console.WriteLine("Enter the number of steps: ");
            int stepCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < stepCount; i++)
            {
                Console.WriteLine("Enter step description: ");
                string description = Console.ReadLine();

                steps.Add($"{i + 1}. {description}");
            }
        }

        public void DisplayRecipe()
        {
            Console.WriteLine($"Recipe: {Name}");
            Console.WriteLine("Ingredients:");

            foreach (Ingredient ingredient in ingredients)
            {
                Console.WriteLine(ingredient);
            }

            Console.WriteLine("Steps:");

            foreach (string step in steps)
            {
                Console.WriteLine(step);
            }

            int totalCalories = CalculateTotalCalories();
            Console.WriteLine($"Total Calories: {totalCalories}");

            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: Recipe exceeds 300 calories.");
            }
        }

        private int CalculateTotalCalories()
        {
            int totalCalories = 0;

            foreach (Ingredient ingredient in ingredients)
            {
                totalCalories += ingredient.Calories;
            }

            return totalCalories;
        }
    }
}
