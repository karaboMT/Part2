﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{
    namespace RecipeApplication
    {
        class Ingredient
        {
            public string Name { get; set; }
            public string Quantity { get; set; }
            public string Unit { get; set; }
            public int Calories { get; set; }
            public string FoodGroup { get; set; }

            public override string ToString()
            {
                return $"{Name} - {Quantity} {Unit} - Calories: {Calories} - Food Group: {FoodGroup}";
            }
        }
    }

}
