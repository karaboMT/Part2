﻿using RecipeApp;
using System;

namespace RecipeApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            RecipeManager recipeManager = new RecipeManager();

            while (true)
            {
                Console.WriteLine("1. Create a new recipe");
                Console.WriteLine("2. Display all recipes");
                Console.WriteLine("3. Select a recipe");
                Console.WriteLine("4. Exit");
                Console.WriteLine("Enter your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Recipe recipe = new Recipe();
                        recipe.EnterDetails();
                        recipeManager.AddRecipe(recipe);
                        break;
                    case "2":
                        recipeManager.DisplayRecipes();
                        break;
                    case "3":
                        Console.WriteLine("Enter the recipe name: ");
                        string recipeName = Console.ReadLine();
                        recipeManager.DisplayRecipe(recipeName);
                        break;
                    case "4":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }
    }
}
